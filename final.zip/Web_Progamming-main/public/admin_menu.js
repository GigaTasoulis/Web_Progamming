// Get all elements with the 'price' class
const prices = document.querySelectorAll('.price');

// Loop through each 'price' element
prices.forEach(price => {
// Create a new button element
const button = document.createElement('button');
button.classList.add('edit-button');
button.style.backgroundImage = "url('/img/photos/edit.png')";

// Append the button to the 'price' element
price.appendChild(button);
});	

// get all elements with class "ppb_title"
const ppbTitles = document.querySelectorAll('.ppb_title');

// loop through the elements and insert a button after each one
ppbTitles.forEach(title => {
  const button = document.createElement('button');
  button.innerText = 'Προσθήκη Νέου Πιάτου';
  button.classList.add('btn', 'btn-primary');
  button.style.border = '1px solid black';
  button.style.marginTop = '1.25%';
  button.style.marginBottom = '1.25%';
  
  const wrapper = document.createElement('div');
  wrapper.style.textAlign = 'center';
  wrapper.appendChild(button);
  
  title.parentNode.insertBefore(wrapper, title.nextElementSibling);
});
























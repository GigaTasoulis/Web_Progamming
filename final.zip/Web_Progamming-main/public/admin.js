const links = document.querySelectorAll('.navbar-nav a');
const currentLocation = location.href;

for (let i = 0; i < links.length; i++) {
  if (links[i].href === currentLocation) {
    links[i].classList.add('active');
    if (links[i].classList.contains('dropdown-item')) {
      links[i].closest('.dropdown').querySelector('.nav-link').classList.add('active');
    } else {
      links[i].closest('.nav-item').querySelector('.nav-link').classList.add('active');
    }
  }
}

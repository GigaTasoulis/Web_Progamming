const express = require('express');
const sessions = require('express-session');
const cookieParser = require("cookie-parser");
const http = require('http');
const fs = require('fs');
const app = express();
const router = express.Router();
const port = 3000;
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const hbs = require('hbs');
// creating 24 hours from milliseconds
const oneDay = 1000 * 60 * 60 * 24;


hbs.registerPartials(__dirname + '/views/partials');

// Set up view engine
app.set('view engine', 'hbs');


// use jQuery here

// Open a database connection
const db = new sqlite3.Database('./restaurant_database.db', sqlite3.OPEN_READWRITE, (err) =>{
  if (err) return console.error(err);
});
// Serve static files from the 'public' directory
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// cookie parser middleware
app.use(cookieParser());
// Set up session middleware
app.use(
  sessions({
    secret: 'thisismysecrctekeyfhrgfgrfrty84fwir767',
    resave: false,
    cookie: { maxAge: oneDay },
    saveUninitialized: false
  })
);
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));





// Routes
app.get('/', (req, res) => {
  res.render('main');
});

app.get('/menu', (req, res) => {
  res.render('menu');
});

app.get('/main', (req, res) => {
  res.render('main');
});

app.get('/user_main', (req, res) => {
  res.render('user_main');
});
app.get('/user_menu', (req, res) => {
  res.render('user_menu');
});
app.get('/admin_main', (req, res) => {
  res.render('admin_main');
});
app.get('/admin_menu', (req, res) => {
  res.render('admin_menu');
});


// Serve user_main.html
app.get('/register', (req, res) => {
  res.render('user_main');
});

app.get('/logout', (req, res) => {
 
  // Destroy the session and clear session data
  req.session.destroy((err) => {
    if (err) {
      console.error('Failed to destroy session:', err);
    }
    // Redirect the user to the login page or any other appropriate page
    res.render('main');
  });
  
});

// Assuming you have already set up your Express server and connected to the database

// Route for admin_reservations.html
app.get('/admin_reservations.ejs', (req, res) => {
  // Fetch reservations data from the database
  const sql = 'SELECT * FROM KRATHSH';
  db.all(sql, (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('An error occurred while fetching reservations');
    }

    // Pass the reservations data to the admin_reservations.html template
    res.render('admin_reservations.ejs', { reservations: rows });
  });
});

app.get('/user_history.ejs', (req, res) => {
  // Retrieve the user ID from the session or authentication state
  const userId = req.session.user.username; // Replace this with your actual user ID retrieval method

  // Use the user ID to query the database for reservations
  const sql = 'SELECT * FROM KRATHSH JOIN KANEI ON id=ID_KRATHSHS WHERE Username = ?';
  db.all(sql, [userId], (err, rows) => {
    if (err) {
      console.error('Error fetching reservations:', err);
      res.status(500).json({ error: 'Failed to fetch reservations' });
      return;
    }

    // Pass the reservations data to the frontend
    res.render('user_history.ejs', {reservations: rows});
  });
});



// Route for enabling editing/cancelling of the reservations
// Update a reservation
app.put('/reservations/:id', (req, res) => {
  const { id } = req.params;
  const updatedReservation = req.body;

  // Update the reservation in the database using the provided ID
  const sql = 'UPDATE KRATHSH SET ONOMA = ?, EMAIL = ?, THLEFWNO = ?, HMEROMHNIA = ?, WRA = ?, ATOMA = ?, EIDIKO_AITHMA = ? WHERE ID = ?';
  const params = [
    updatedReservation.ONOMA,
    updatedReservation.EMAIL,
    updatedReservation.THLEFWNO,
    updatedReservation.HMEROMHNIA,
    updatedReservation.WRA,
    updatedReservation.ATOMA,
    updatedReservation.EIDIKO_AITHMA,
    id
  ];

  db.run(sql, params, (err) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ message: 'An error occurred while updating the reservation' });
    }
    console.log('Reservation edited succesfully');
    return res.status(200).json({ message: 'Reservation updated successfully' });
  });
});

// Handle reservation cancellation
app.delete('/reservations/:id', (req, res) => {
  const reservationId = req.params.id;

  // Delete the reservation from the database
  db.run('DELETE FROM KRATHSH WHERE ID = ?', reservationId, (err) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Error canceling reservation');
    } else {
      res.sendStatus(200);
    }
  });
  db.run('DELETE FROM KANEI WHERE ID_KRATHSHS = ?', reservationId, (err) => {
    if (err) {
      console.error(err.message);
    }
  });
});




// Routes


app.post('/login', (req, res) => {
  const { username, password } = req.body;
  // Check if the user exists in the appropriate table and the password is correct
  const userSql = 'SELECT * FROM XRHSTHS WHERE Username = ?';
  const adminSql = 'SELECT * FROM DIAXEIRISTHS WHERE Username = ?';
  
  
  // First, check if the user is an admin
  db.get(adminSql, [username], (err, adminRow) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ message: 'An error occurred while trying to log in' });
    } else if (adminRow && adminRow.Password === password) {
      // Admin credentials are correct, start a new session and store the user information
      req.session.regenerate((err) => {
        if (err) {
          console.error('Failed to regenerate session:', err);
          return res.status(500).json({ message: 'An error occurred while logging in' });
        }

        req.session.user = {
          username: adminRow.Username,
          email: adminRow.Email,
          password: adminRow.Password
        };
        console.log('\nAuthenticated admin:', username); // Log the authenticated admin
        console.log('Session:', req.session);
        console.log('Redirecting to admin_main'); // Log the redirection
        return res.render('admin_main');
      });
    } else {
      // The user is not an admin, check if they exist in the regular user table
      db.get(userSql, [username], (err, userRow) => {
        if (err) {
          console.error(err.message);
          return res.status(500).json({ message: 'An error occurred while trying to log in' });
        } else if (!userRow) {
          // Username not found, display error message
          res.status(400).json({ message: 'Incorrect username or password' });
        } else if (userRow.Password !== password) {
          // Incorrect password, display error message
          res.status(400).json({ message: 'Incorrect username or password' });
        } else {
          // Regular user credentials are correct, start a new session and store the user information
          req.session.regenerate((err) => {
            if (err) {
              console.error('Failed to regenerate session:', err);
              return res.status(500).json({ message: 'An error occurred while logging in' });
            }

            req.session.user = {
              username: userRow.Username,
              email: userRow.Email,
              password: userRow.Password
            };
            console.log('\nAuthenticated user:', username); // Log the authenticated user
            console.log('Session:', req.session);
            console.log('Redirecting to user_main'); // Log the redirection
            res.render('user_main');
          });
        }
      });
    }
  });
});




app.use(bodyParser.urlencoded({ extended: true }));

// Handle form submission from user
app.post('/submit', (req, res) => {
  const selectedTime = req.body.time;
  const seats = req.body.seats;
  const message = req.body.message;
  const submitDate = new Date().toISOString().split('T')[0];
  const { your_name, email, phone, date } = req.body;
  const username = req.session.user.username; // Assuming the username is stored in the session


  // Check if the number of reservations for the selected time period exceeds the limit
  db.get(
    'SELECT COUNT(*) AS reservationCount FROM KRATHSH WHERE WRA = ?',
    [selectedTime],
    (err, row) => {
      if (err) {
        console.error(err.message);
        res.status(500).send('Error creating reservation');
        return;
      }

      const reservationCount = row.reservationCount;

      if (reservationCount < 10) {
        // Get the highest reservation ID from the database
        db.get('SELECT MAX(id) AS maxId FROM KRATHSH', (err, row) => {
          if (err) {
            console.error(err.message);
            res.status(500).send('Error creating reservation');
            return;
          }

          const reservationId = row.maxId + 1; // Generate the next reservation ID

          // Insert the reservation data into the database
          db.run(
            'INSERT INTO KRATHSH (id, ONOMA, EMAIL, THLEFWNO, HMEROMHNIA, WRA, ATOMA, EIDIKO_AITHMA, HMEROMHNIA_YPOBOLHS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [reservationId, your_name, email, phone, date, selectedTime, seats, message, submitDate],
            (err) => {
              if (err) {
                console.error(err.message);
                res.render('user_main');
              } else {
                // Insert data into the "KANEI" table
                const submitDate = new Date().toISOString().split('T')[0];  // Get the current date and time
                db.run(
                  'INSERT INTO KANEI (Username, ID_KRATHSHS, HMNIA) VALUES (?, ?, ?)',
                  [username, reservationId, submitDate],
                  (err) => {
                    if (err) {
                      console.error(err.message);
                      res.render('user_main');
                    } else {
                      res.render('user_main');
                    }
                  }
                );
              }
            }
          );
        });
      } else {
        // Disable the option for this time period
        // Modify your Handlebars template or dynamically disable the option using JavaScript
        res.render('user_main');
      }
    }
  );
});



// Handle form submission from admin
app.post('/admin_submit', (req, res) => {
  const selectedTime = req.body.time;
  const seats = req.body.seats;
  const message = req.body.message;
  const submitDate = new Date().toISOString().split('T')[0];
  const { your_name, email, phone, date } = req.body;
  const username = "admin"; // Assuming the username is stored in the session
  // Get the highest reservation ID from the database
  db.get('SELECT MAX(id) AS maxId FROM KRATHSH', (err, row) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Error creating reservation');
      return;
    }

    const reservationId = row.maxId + 1; // Generate the next reservation ID

    // Insert the reservation data into the database
    db.run(
      'INSERT INTO KRATHSH (id, ONOMA, EMAIL, THLEFWNO, HMEROMHNIA, WRA, ATOMA, EIDIKO_AITHMA, HMEROMHNIA_YPOBOLHS, ADMIN_USERNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [reservationId, your_name, email, phone, date, selectedTime, seats, message, submitDate, username],
      (err) => {
        if (err) {
          console.error(err.message);
          res.redirect('/admin_reservations.ejs');
        } else {
          // Insert data into the "KANEI" table
          const submitDate = new Date().toISOString().split('T')[0];  // Get the current date and time
          db.run(
            'INSERT INTO KANEI (Username, ID_KRATHSHS, HMNIA) VALUES (?, ?, ?)',
            [username, reservationId, submitDate],
            (err) => {
              if (err) {
                console.error(err.message);
                res.redirect('/admin_reservations.ejs');
              } else {
                res.redirect('/admin_reservations.ejs');
              }
            }
          );
        }
      }
    );
  });
});



// POST request for registering
app.post('/register', (req, res) => {
  const { email, username, password } = req.body;


  // Insert the user data into the database
  db.run('INSERT INTO XRHSTHS (Username,Password,Email) VALUES (?,?,?)',
    [username, password, email],
    (err) => {
      if (err) {
        console.error(err.message);
        res.status(500).send('Error registering user');
        db.close((err) => {
          if (err) {
            console.error(err.message);
          } else {
            console.log('Connection closed successfully');
          }
        });
      } else {
        // Redirect to user_main.html on successful registration
        res.render('user_main');
      }
    }
  );
  
});












app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`);
});







